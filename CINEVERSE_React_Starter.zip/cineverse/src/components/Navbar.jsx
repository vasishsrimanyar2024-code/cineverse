import { NavLink, Link } from 'react-router-dom'
import { Clapperboard, Compass, Bookmark, UserRound, Menu, X } from 'lucide-react'
import { useState } from 'react'
import { useWatchlist } from '../context/WatchlistContext'

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const { watchlist } = useWatchlist()
  const links = [
    { to: '/', label: 'Home' },
    { to: '/explore', label: 'Explore' },
    { to: '/genres', label: 'Genres' },
    { to: '/watchlist', label: 'Watchlist' },
    { to: '/about', label: 'About' },
  ]
  return <header className="topbar">
    <div className="nav-wrap">
      <Link to="/" className="brand" onClick={() => setOpen(false)}><span className="brand-mark"><Clapperboard size={19}/></span><span>CINE<span>VERSE</span></span></Link>
      <nav className={open ? 'nav-links open' : 'nav-links'}>
        {links.map(link => <NavLink key={link.to} to={link.to} end={link.to === '/'} onClick={() => setOpen(false)}>{link.label}{link.to === '/watchlist' && <span className="nav-count">{watchlist.length}</span>}</NavLink>)}
      </nav>
      <div className="nav-actions"><Link to="/profile" className="profile-link" aria-label="Profile"><UserRound size={18}/></Link><button className="mobile-menu" onClick={() => setOpen(!open)} aria-label="Toggle menu">{open ? <X/> : <Menu/>}</button></div>
    </div>
  </header>
}