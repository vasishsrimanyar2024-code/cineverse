import { Link } from 'react-router-dom'
import { Clapperboard } from 'lucide-react'
export default function Footer() {
  return <footer className="footer"><div className="footer-inner"><Link to="/" className="brand"><span className="brand-mark"><Clapperboard size={18}/></span><span>CINE<span>VERSE</span></span></Link><p>Your next favourite movie is one discovery away.</p><span className="copyright">© {new Date().getFullYear()} CINEVERSE. A movie discovery project.</span></div></footer>
}