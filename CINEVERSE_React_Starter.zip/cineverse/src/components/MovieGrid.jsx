import MovieCard from './MovieCard'
import { Film } from 'lucide-react'
export default function MovieGrid({ items }) {
  if (!items.length) return <div className="empty-state"><Film size={30}/><h3>No movies found</h3><p>Try changing your search or filters.</p></div>
  return <div className="movie-grid">{items.map(movie => <MovieCard key={movie.id} movie={movie}/>)}</div>
}