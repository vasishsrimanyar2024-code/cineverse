import { Link } from 'react-router-dom'
import { Bookmark, Star, Check } from 'lucide-react'
import { useWatchlist } from '../context/WatchlistContext'

export default function MovieCard({ movie }) {
  const { isSaved, toggleSaved, isWatched } = useWatchlist()
  return <article className="movie-card">
    <div className="poster-wrap">
      <Link to={`/movie/${movie.id}`}><img className="poster" src={movie.poster} alt={`${movie.title} poster`} loading="lazy" onError={e => { e.currentTarget.src = 'https://placehold.co/500x750/1d222b/f5f5f5?text=Movie+Poster' }}/></Link>
      <button className={`save-btn ${isSaved(movie.id) ? 'saved' : ''}`} onClick={() => toggleSaved(movie.id)} aria-label={isSaved(movie.id) ? 'Remove from watchlist' : 'Add to watchlist'}><Bookmark size={17} fill={isSaved(movie.id) ? 'currentColor' : 'none'}/></button>
      {isWatched(movie.id) && <span className="watched-tag"><Check size={12}/> Watched</span>}
    </div>
    <div className="movie-meta"><div><Link to={`/movie/${movie.id}`} className="movie-title">{movie.title}</Link><span className="movie-year">{movie.year}</span></div><span className="rating"><Star size={13} fill="currentColor"/>{movie.rating}</span></div>
    <div className="card-genres">{movie.genres.slice(0, 2).join(' · ')}</div>
  </article>
}