import { Link } from 'react-router-dom'
import { ArrowRight, Play, Sparkles } from 'lucide-react'
import { movies } from '../data/movies'
import MovieGrid from '../components/MovieGrid'
import SectionHeading from '../components/SectionHeading'

export default function Home() {
  const featured = movies.find(m => m.featured)
  return <main>
    <section className="hero" style={{ backgroundImage: `linear-gradient(90deg, #111318 4%, rgba(17,19,24,.92) 34%, rgba(17,19,24,.25) 100%), linear-gradient(0deg,#111318 0%,transparent 42%), url(${featured.backdrop})` }}>
      <div className="hero-content"><span className="eyebrow"><Sparkles size={14}/> YOUR MOVIE DISCOVERY SPACE</span><p className="hero-kicker">TONIGHT'S FEATURED FILM</p><h1>Stories worth<br/><em>staying up for.</em></h1><p className="hero-copy">Find your next favourite. Explore handpicked films, follow your curiosity and keep your watchlist close.</p><div className="hero-buttons"><Link className="btn btn-primary" to={`/movie/${featured.id}`}><Play size={16} fill="currentColor"/> Explore featured</Link><Link className="btn btn-ghost" to="/explore">Browse movies <ArrowRight size={16}/></Link></div><div className="hero-feature-meta"><span><strong>{featured.rating}</strong> / 10 rating</span><span>{featured.year}</span><span>{featured.duration}</span></div></div>
      <div className="hero-index"><span>01</span><i/> FEATURED PICK</div>
    </section>
    <section className="page-section"><SectionHeading eyebrow="A GOOD PLACE TO START" title="Trending discoveries" action={<Link className="text-link" to="/explore">Explore all <ArrowRight size={15}/></Link>}/><MovieGrid items={movies.slice(0, 6)}/></section>
    <section className="genre-strip"><div><span className="eyebrow">FOLLOW A FEELING</span><h2>What are you<br/>in the mood for?</h2></div><div className="genre-pills">{['Thriller','Crime','Sci-Fi','Drama','Comedy','Horror'].map(g => <Link key={g} to={`/genres?genre=${g}`}>{g}<ArrowRight size={14}/></Link>)}</div></section>
    <section className="page-section"><SectionHeading eyebrow="HIGHLY RATED" title="Worth your time"/><MovieGrid items={[...movies].sort((a,b)=>b.rating-a.rating).slice(0, 4)}/></section>
  </main>
}