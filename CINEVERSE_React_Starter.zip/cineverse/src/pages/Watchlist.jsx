import { Link } from 'react-router-dom'
import { Bookmark, CheckCircle2 } from 'lucide-react'
import { movies } from '../data/movies'
import { useWatchlist } from '../context/WatchlistContext'
import MovieGrid from '../components/MovieGrid'
import SectionHeading from '../components/SectionHeading'

export default function Watchlist() {
  const { watchlist, watched } = useWatchlist()
  const saved = movies.filter(m=>watchlist.includes(m.id))
  const seen = movies.filter(m=>watched.includes(m.id))
  return <main className="content-page"><div className="page-intro"><span className="eyebrow">YOUR PERSONAL COLLECTION</span><h1>My <em>watchlist.</em></h1><p>All the stories you want to come back to.</p></div><div className="stat-row"><div className="stat-card"><Bookmark/><strong>{saved.length}</strong><span>Saved movies</span></div><div className="stat-card"><CheckCircle2/><strong>{seen.length}</strong><span>Marked as watched</span></div></div><SectionHeading title="Saved for later"/>{saved.length ? <MovieGrid items={saved}/> : <div className="empty-state"><Bookmark size={30}/><h3>Your watchlist is waiting</h3><p>Save movies you want to watch next.</p><Link className="btn btn-primary" to="/explore">Find a movie</Link></div>}</main>
}