import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, Bookmark, Check, Clock3, Star } from 'lucide-react'
import { movies } from '../data/movies'
import { useWatchlist } from '../context/WatchlistContext'

export default function MovieDetails() {
  const { id } = useParams()
  const movie = movies.find(m => m.id === Number(id))
  const { isSaved, toggleSaved, isWatched, toggleWatched } = useWatchlist()
  if (!movie) return <main className="content-page"><div className="empty-state"><h2>Movie not found</h2><Link className="btn btn-primary" to="/explore">Back to explore</Link></div></main>
  return <main className="details-page"><div className="details-backdrop" style={{backgroundImage:`linear-gradient(90deg,#111318 5%,rgba(17,19,24,.88) 48%,rgba(17,19,24,.38)),linear-gradient(0deg,#111318,transparent 70%),url(${movie.backdrop || movie.poster})`}}/><div className="details-content"><Link to="/explore" className="back-link"><ArrowLeft size={16}/> Back to explore</Link><div className="details-layout"><img className="details-poster" src={movie.poster} alt={`${movie.title} poster`} onError={e=>{e.currentTarget.src='https://placehold.co/500x750/1d222b/f5f5f5?text=Movie+Poster'}}/><div className="details-info"><span className="eyebrow">MOVIE PROFILE</span><h1>{movie.title}</h1><div className="details-facts"><span>{movie.year}</span><span><Clock3 size={14}/>{movie.duration}</span><span><Star size={14} fill="currentColor"/>{movie.rating} / 10</span></div><div className="tag-row">{movie.genres.map(g=><span className="tag" key={g}>{g}</span>)}</div><h3>Overview</h3><p className="overview">{movie.overview}</p><div className="detail-credit"><span>DIRECTOR</span><strong>{movie.director}</strong></div><div className="hero-buttons"><button className="btn btn-primary" onClick={()=>toggleSaved(movie.id)}><Bookmark size={16} fill={isSaved(movie.id)?'currentColor':'none'}/>{isSaved(movie.id)?'Saved to watchlist':'Add to watchlist'}</button><button className="btn btn-ghost" onClick={()=>toggleWatched(movie.id)}><Check size={16}/>{isWatched(movie.id)?'Marked as watched':'Mark as watched'}</button></div></div></div></div></main>
}