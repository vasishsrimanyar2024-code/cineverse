import { UserRound, Bookmark, CheckCircle2, Film } from 'lucide-react'
import { movies } from '../data/movies'
import { useWatchlist } from '../context/WatchlistContext'
import MovieGrid from '../components/MovieGrid'
import { Link } from 'react-router-dom'

export default function Profile() {
  const {watchlist,watched}=useWatchlist()
  const saved=movies.filter(m=>watchlist.includes(m.id))
  return <main className="content-page"><div className="page-intro"><span className="eyebrow">YOUR CINEVERSE</span><h1>Movie <em>profile.</em></h1><p>A little snapshot of your movie journey.</p></div><div className="profile-panel"><div className="avatar"><UserRound size={34}/></div><div><span className="eyebrow">CINEVERSE MEMBER</span><h2>Movie Explorer</h2><p>Curious about stories. Always finding the next one.</p></div></div><div className="stat-row"><div className="stat-card"><Bookmark/><strong>{watchlist.length}</strong><span>Watchlist saves</span></div><div className="stat-card"><CheckCircle2/><strong>{watched.length}</strong><span>Movies watched</span></div><div className="stat-card"><Film/><strong>{movies.length}</strong><span>Movies available</span></div></div><div className="section-heading"><div><span className="eyebrow">PICKING UP WHERE YOU LEFT OFF</span><h2>Your saved movies</h2></div><Link className="text-link" to="/watchlist">View watchlist</Link></div>{saved.length?<MovieGrid items={saved.slice(0,4)}/>:<div className="empty-state"><Bookmark/><h3>No saved movies yet</h3><p>Your watchlist will appear here.</p><Link className="btn btn-primary" to="/explore">Explore movies</Link></div>}</main>
}