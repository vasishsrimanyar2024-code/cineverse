import { useMemo, useState } from 'react'
import { Search, SlidersHorizontal, X } from 'lucide-react'
import { movies, genres } from '../data/movies'
import MovieGrid from '../components/MovieGrid'

export default function Explore() {
  const [query, setQuery] = useState('')
  const [genre, setGenre] = useState('All')
  const [sort, setSort] = useState('popular')
  const filtered = useMemo(() => {
    const result = movies.filter(m => m.title.toLowerCase().includes(query.toLowerCase()) && (genre === 'All' || m.genres.includes(genre)))
    if (sort === 'rating') result.sort((a,b) => b.rating-a.rating)
    if (sort === 'year') result.sort((a,b) => b.year-a.year)
    if (sort === 'title') result.sort((a,b) => a.title.localeCompare(b.title))
    return result
  }, [query, genre, sort])
  return <main className="content-page"><div className="page-intro"><span className="eyebrow">THE COLLECTION</span><h1>Explore <em>movies.</em></h1><p>Search, filter and find something worth watching.</p></div>
    <div className="filter-panel"><label className="search-field"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search movie titles..."/>{query && <button onClick={()=>setQuery('')}><X size={16}/></button>}</label><label className="select-field"><SlidersHorizontal size={16}/><select value={genre} onChange={e=>setGenre(e.target.value)}>{genres.map(g=><option key={g}>{g}</option>)}</select></label><label className="select-field"><select value={sort} onChange={e=>setSort(e.target.value)}><option value="popular">Default order</option><option value="rating">Highest rated</option><option value="year">Newest first</option><option value="title">Title A–Z</option></select></label></div>
    <div className="results-line"><span>{filtered.length} movies</span><span>CURATED FOR CURIOUS MINDS</span></div><MovieGrid items={filtered}/>
  </main>
}