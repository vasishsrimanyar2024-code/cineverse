import { Link, useSearchParams } from 'react-router-dom'
import { ArrowUpRight, Film } from 'lucide-react'
import { genres, movies } from '../data/movies'
import MovieGrid from '../components/MovieGrid'

const descriptions = { Action:'Big energy, bold heroes and unforgettable set pieces.', Adventure:'Journeys that take you somewhere unexpected.', Animation:'Imagination brought to life, frame by frame.', Comedy:'A little laughter goes a long way.', Crime:'Complex characters and stories from the edge.', Drama:'Human stories that stay with you.', Horror:'For those who like a little suspense.', Music:'Stories with rhythm, sound and soul.', Mystery:'Follow the clues and see where they lead.', Romance:'Stories about connection and love.', 'Sci-Fi':'Ideas and worlds beyond the ordinary.', Thriller:'Tension, twists and edge-of-your-seat storytelling.' }
export default function Genres() {
  const [params,setParams] = useSearchParams()
  const selected = params.get('genre') || 'All'
  const list = movies.filter(m=>selected==='All'||m.genres.includes(selected))
  return <main className="content-page"><div className="page-intro"><span className="eyebrow">PICK YOUR MOOD</span><h1>Explore by <em>genre.</em></h1><p>Every mood has a movie. Start with a feeling.</p></div><div className="genre-browser">{genres.filter(g=>g!=='All').map((g,i)=><button key={g} className={`genre-tile ${selected===g?'active':''}`} onClick={()=>setParams({genre:g})}><span>0{i+1}</span><strong>{g}</strong><ArrowUpRight size={18}/></button>)}</div><div className="genre-selected"><div><span className="eyebrow">NOW BROWSING</span><h2>{selected==='All'?'All movies':selected}</h2><p>{descriptions[selected] || 'Explore the complete collection.'}</p></div><button className="clear-filter" onClick={()=>setParams({})}>Show all</button></div><MovieGrid items={list}/></main>
}