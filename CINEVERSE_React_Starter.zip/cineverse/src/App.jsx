import { Routes, Route } from 'react-router-dom'
import { WatchlistProvider } from './context/WatchlistContext'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Home from './pages/Home'
import Explore from './pages/Explore'
import MovieDetails from './pages/MovieDetails'
import Watchlist from './pages/Watchlist'
import Genres from './pages/Genres'
import Profile from './pages/Profile'
import About from './pages/About'

export default function App() {
  return <WatchlistProvider><div className="app-shell"><Navbar/><Routes><Route path="/" element={<Home/>}/><Route path="/explore" element={<Explore/>}/><Route path="/movie/:id" element={<MovieDetails/>}/><Route path="/watchlist" element={<Watchlist/>}/><Route path="/genres" element={<Genres/>}/><Route path="/profile" element={<Profile/>}/><Route path="/about" element={<About/>}/><Route path="*" element={<main className="content-page"><h1>Page not found</h1></main>}/></Routes><Footer/></div></WatchlistProvider>
}