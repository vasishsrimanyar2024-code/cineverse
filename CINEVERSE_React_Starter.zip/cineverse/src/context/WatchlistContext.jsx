import { createContext, useContext, useEffect, useMemo, useState } from 'react'

const WatchlistContext = createContext(null)

export function WatchlistProvider({ children }) {
  const [watchlist, setWatchlist] = useState(() => JSON.parse(localStorage.getItem('cineverse-watchlist') || '[]'))
  const [watched, setWatched] = useState(() => JSON.parse(localStorage.getItem('cineverse-watched') || '[]'))

  useEffect(() => localStorage.setItem('cineverse-watchlist', JSON.stringify(watchlist)), [watchlist])
  useEffect(() => localStorage.setItem('cineverse-watched', JSON.stringify(watched)), [watched])

  const value = useMemo(() => ({
    watchlist,
    watched,
    isSaved: id => watchlist.includes(id),
    toggleSaved: id => setWatchlist(old => old.includes(id) ? old.filter(x => x !== id) : [...old, id]),
    isWatched: id => watched.includes(id),
    toggleWatched: id => setWatched(old => old.includes(id) ? old.filter(x => x !== id) : [...old, id]),
  }), [watchlist, watched])

  return <WatchlistContext.Provider value={value}>{children}</WatchlistContext.Provider>
}

export function useWatchlist() {
  const context = useContext(WatchlistContext)
  if (!context) throw new Error('useWatchlist must be used inside WatchlistProvider')
  return context
}