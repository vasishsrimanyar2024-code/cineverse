# CINEVERSE

A beginner-friendly React movie discovery and watchlist website.

## Run in VS Code

1. Extract this ZIP file.
2. Open the extracted `cineverse` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:

```bash
npm install
npm run dev
```

5. Open the local URL shown in the terminal (usually http://localhost:5173).

## Build for deployment

```bash
npm run build
```

The production website is generated in the `dist` folder. You can deploy the GitHub repository to Vercel with build command `npm run build` and output directory `dist`.

## Included features

- Home page with featured movie and curated collections
- Explore page with title search, genre filters and sorting
- Movie detail pages
- Watchlist saved in browser LocalStorage
- Watched status
- Genre browsing
- Profile summary
- About and contact page
- Responsive desktop and mobile layout

## Notes

- This is a frontend demo. Watchlist data is saved in the current browser only.
- Movie information is a sample local dataset, not a live movie database.
- Poster artwork loads from TMDB image CDN. Internet access is needed for those images.
- No movie streaming or copyrighted movie files are hosted by this project.
